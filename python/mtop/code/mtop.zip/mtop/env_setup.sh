export MVHAL_ROOT=/home/hemaolin/work/tda4/gac/x3v/src/git/mv_hal
export TDA4_ROOT=/home/hemaolin/work/tda4

export SDK_ROOT=$TDA4_ROOT/gac/x3v/sdk/rtos_sdk_7.1_a58
export QNX_BASE=/home/hemaolin/Downloads/a58_qnx710_psdk/psdkra/psdkqa/sdp/
export QNX_HOST=$QNX_BASE/host/linux/x86_64
export QNX_TARGET=$QNX_BASE/target/qnx7
export TOOLCHAIN_ROOT=$QNX_HOST/usr/bin
export PATH=$PATH:$QNX_HOST/usr/bin
