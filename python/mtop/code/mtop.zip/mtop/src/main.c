#include <stdio.h>
#include <sys/stat.h>
int main() {
    struct stat buf;
    if (stat("/proc", &buf) != -1) {
        printf("Mem free = %ld\n", buf.st_size);
    }
}
